Old Outhouse prop for Poser
Copyright 2005 Del Schu (deljs).

All of this product's content was created by deljs.
deljs3d@pacifier.com


INSTALLATION & CONTENTS
Extract the zip file with "Use Folder Names" checked (Winzip).

Files will be placed in the following locations:

\runtime\textures\Deljs\oldOuthouse\
P5071762_1024.jpg
P5071936_1024.jpg
rust01_512.jpg

\runtime\libraries\Props\Deljs\oldOuthouse\
FlyStrip.png
FlyStrip.pp2
OldOuthouse.png
ToiletPaper.png
ToiletPaper.pp2
oldOuthouse.pp2

Readme_OldOuthouse.txt



TIPS
To open/close the door, select the "Door" item and turn the Door Open/Close dial on the Parameters palette. Select Figure > Use Limits in main menu to limit door rotation.

The toilet paper and flystrip props are intended to be loaded separately from the main outhouse model for scene flexibility. However, if used, they are parented to "Outhouse".

Uncheck "Smooth polygons" in FireFly Render Settings for best rendering results.



USAGE
You may use these files to render commercial or non-commercial images or animations. All other rights reserved.

Please do not sell or redistribute any of these files in whole, modified, or in part for any reason without permission. Please do not claim any of these files as your own work.


I would very much appreciate if you'd send me a link to any posted images you use these props in; but its certainly not necessary.


Hope you find it useful.
Thanks for checking it out!

deljs


5/2005